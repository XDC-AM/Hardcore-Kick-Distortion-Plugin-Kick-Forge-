# KickForge 2.1.2 — Darkaero

**硬核 kick 专用三频段失真器 / Hardcore Kick Forge**

KickForge 是一个为 **Hardstyle / Rawstyle / Frenchcore / Gabber / Uptempo / Hardcore** 制作 kick 的 64 位 VST2 插件。它把输入 kick 拆成 **LOW / MID / HIGH** 三个频段，分别做非线性整形，再经过 punch、body、tone、bitcrush、mono、low-cut 和砖墙 ceiling，输出可直接进 FL Studio 的硬核 kick。

UI 2.1.2 使用 **Darkaero** 视觉：冷蓝灰金属、玻璃面板、镀铬细边、机加工旋钮、分段电平表和 kick 示波器；没有照片背景，也没有危险条纹。界面提供 **两种 DARKAERO 外观**（STYLE 01 冷铬玻璃 / STYLE 02 黑色分段铬甲）和 **四种强调色**（ORIGINAL 冰蓝、MAGENTA 品红、CRIMSON 深红、INK BLUE 墨蓝），比例可在 **100% / 125% / 150%** 间切换，XDC-AM 署名固定在主界面与设置页。

!\[KickForge Darkaero UI](assets/ui\_preview.png)

!\[Darkaero style and accent matrix](assets/darkaero\_style\_matrix.png)

\---

## 1\. 功能

* **27 个参数**，覆盖输入、三频段驱动/混合、分频、瞬态、body、tone、bitcrush、宽度、mono、低切、自动增益、过采样、输出和 ceiling。
* **三频段 LR4 分频**：LOW / MID / HIGH 独立 drive 与 mix，默认 140 Hz / 2.2 kHz，可调。
* **6 种非线性曲线**：TUBE、HARD、FOLD、DIODE、GABBER、CRUSH。
* **1x / 2x / 4x / 8x 过采样**，31-tap 半带 FIR。
* **Punch / Body / Tone**：瞬态强调、低频 shelf、倾斜 EQ。
* **Bitcrush + 降采样**：Rate 1x–32x，Crush 0–100%。
* **Width / Mono / Low Cut**：控制立体声宽度、单声道化和超低频。
* **Soft / Hard ceiling**，输出峰值可调。
* **10 个工厂预设**，覆盖 clean 到 total destruction。
* **A/B 对比、随机、Init、Bypass、Help**。
* **Darkaero UI 2.1.2**：两种外观、四种强调色、三档比例；风格、颜色和比例会写入工程 chunk，并额外保存为用户级全局记忆。
* **稳定性修复**：编辑器窗口登记、DLL 卸载清理、UI 线程设置刷新。

!\[Darkaero UI settings](assets/da2\_settings.png)

\---

## 2\. 在 FL Studio 25 中安装

1. 复制：

```text
   D:\\鱼的工作区\\kickforge\\dist\\KickForge.dll
   ```

   到：

```text
   D:\\FL studio\\Plugins\\VST\\KickForge.dll
   ```

2. 打开 FL Studio（必须使用 **FL64.exe**，64 位）。
3. **Options → Manage plugins**。
4. 确认 VST2 搜索路径包含：

```text
   D:\\FL studio\\Plugins\\VST\\
   ```

5. 点击 **Find more plugins / Scan**。
6. 在插件列表里找到 **KickForge**，拖到 kick 通道。
7. 首次加载后建议重启 FL，让插件数据库刷新。

安装只需要 `KickForge.dll`。**不需要**背景图、主题文件或其他外部资源。

\---

## 3\. UI 2.1.2

### 3.1 主界面

* **INPUT STAGE**：Input / Drive / Mix、Bias、Character。
* **3-BAND FORGE**：LOW / MID / HIGH 的 Drive 与 Mix，以及 Low Split / High Split。
* **SHAPE \& COLOR**：Punch / Body / Tone / Crush。
* **KICK SCOPE**：42 ms 窗口，显示输出波形与峰值。
* **OUTPUT \& UTILITY**：Auto Gain、Mono、Oversample、Clip、Output、Ceiling、Rate、Width、Low Cut、双通道电平。
* **PRESET MEMORY**：预设浏览器、A/B、Random、Init、Bypass、Help、UI SETUP。

### 3.2 UI SETUP

点击预设栏右侧的 **UI SETUP**：

* **INTERFACE SCALE**：100% / 125% / 150%。
* **DARKAERO FINISH**：

  * **STYLE 01 — CHROME GLASS**：冷铬玻璃，默认。
  * **STYLE 02 — BROOD CHROME**：黑色分段铬甲、齿纹旋钮、分段散热条。
* **ACCENT COLOR**：

  * **ORIGINAL**：冰蓝
  * **MAGENTA**：品红
  * **CRIMSON**：深红
  * **INK BLUE**：墨蓝

比例、外观、颜色都会写进 VST chunk（v3），随工程保存。界面始终是程序化绘制，**不加载任何图片背景**。

### 3.3 全局主题记忆（2.1.2）

除工程 chunk 外，UI 还会把最近一次选择写入用户级设置：

```text
%APPDATA%\\KickForge\\settings.ini
```

* 每次切换 **比例 / STYLE / ACCENT COLOR** 都会立即保存。
* 新建工程或重新加载插件时，会先恢复这套全局外观；工程 chunk 里保存的取值仍会覆盖它。
* 如果 `%APPDATA%` 不可写，会退回 DLL 同目录的 `KickForge.ini`。
* 想恢复默认外观：关闭插件，删除 `settings.ini` 或 `KickForge.ini`，再重新打开。

### 3.4 操作

* 旋钮：上下拖动；按住 **Shift** 细调。
* 双击旋钮 / 右键旋钮：恢复默认值。
* 滚轮：微调。
* Character / Oversample / Clip：点击切换。
* 预设栏：点击展开，选择预设。
* A/B：保存/切换两套参数快照。
* Random：随机化音色参数（不会改 oversample / bypass 等全局项）。
* Init：回到 INIT / CLEAN。
* Bypass：旁路。
* Help：显示快捷操作。

\---

## 4\. 信号流程

```text
Input
  → Input trim / DC block
  → LR4 3-band crossover
      LOW  → drive + mix → shaper
      MID  → drive + mix → shaper
      HIGH → drive + mix → shaper
  → sum
  → Punch (transient)
  → Body (low shelf)
  → Tone (tilt EQ)
  → Bitcrush / downsample
  → Width / Mono
  → Low Cut
  → Auto Gain
  → Output
  → Soft/Hard ceiling
```

过采样在非线性段前后进行。1x 时完全旁路半带 FIR；2x/4x/8x 使用 31-tap 半带滤波器。

\---

## 5\. 参数

|参数|范围|默认|说明|
|-|-:|-:|-|
|Input|-24 … +24 dB|0 dB|输入增益|
|Drive|0 … 36 dB|12 dB|总驱动|
|Mix|0 … 100%|100%|干湿比|
|Character|6 种|HARD|非线性曲线|
|Bias|-1 … +1|0|整形偏置|
|Low Drive|0 … 36 dB|0 dB|低频额外驱动|
|Mid Drive|0 … 36 dB|6 dB|中频额外驱动|
|High Drive|0 … 36 dB|12 dB|高频额外驱动|
|Low Mix|0 … 100%|25%|低频整形比例|
|Mid Mix|0 … 100%|100%|中频整形比例|
|High Mix|0 … 100%|100%|高频整形比例|
|Low Split|60 … 400 Hz|140 Hz|低/中分频|
|High Split|800 … 6000 Hz|2.2 kHz|中/高分频|
|Punch|0 … 100%|35%|瞬态强调|
|Body|0 … 100%|45%|低频 shelf|
|Tone|-100 … +100%|0|倾斜 EQ|
|Crush|0 … 100%|0|位深压缩|
|Rate|1x … 32x|1x|降采样保持|
|Width|0 … 200%|100%|立体声宽度|
|Mono|ON/OFF|ON|单声道化|
|Low Cut|20 … 150 Hz|25 Hz|低切|
|Auto Gain|ON/OFF|OFF|RMS 自动增益|
|Oversample|1x/2x/4x/8x|4x|过采样|
|Output|-24 … +12 dB|-4 dB|输出增益|
|Ceiling|-6 … 0 dB|-0.3 dB|峰值上限|
|Clip|SOFT/HARD|SOFT|ceiling 方式|
|Bypass|ON/OFF|OFF|旁路|

**Character 曲线**

* **TUBE**：tanh 类软饱和，圆润。
* **HARD**：0.9 处软拐点削波，硬核 punch。
* **FOLD**：正弦折叠，frenchcore / rawstyle 的撕裂感。
* **DIODE**：不对称指数，带偶次谐波。
* **GABBER**：折叠 + 硬削波，激进。
* **CRUSH**：3-bit 量化，颗粒感。

\---

## 6\. 预设

|#|名称|用途|
|-:|-|-|
|0|INIT / CLEAN|干净参考|
|1|HARDSTYLE PUNCH|标准 hardstyle punch|
|2|RAWSTYLE SERMON|更脏、更硬的中频|
|3|FRENCHCORE FOLD|折叠撕裂|
|4|GABBER HAMMER|极端 gabber|
|5|UPTEMPO STOMP|uptempo 冲击|
|6|INDUSTRIAL SCREAM|工业金属|
|7|SUB KEEPER|保留 sub 的轻失真|
|8|TAIL BURNER|长尾爆炸|
|9|TOTAL DESTRUCTION|完全摧毁|

\---

## 7\. 快速配方

### Hardstyle Punch

1. 载入 **HARDSTYLE PUNCH**。
2. Low Split 140 Hz，High Split 2.2 kHz。
3. Drive 12 dB，Character HARD，Punch 35%。
4. Mono ON，Oversample 4x。
5. 用 Output / Ceiling 把峰值压到 -1 dB 左右。

### Frenchcore Fold

1. 载入 **FRENCHCORE FOLD**。
2. Character FOLD 或 GABBER。
3. 提高 Mid Drive / High Drive。
4. Crush 10–30%，Rate 2x–4x。
5. 保持 Mono ON，避免低频相位问题。

### Gabber Hammer

1. 载入 **GABBER HAMMER**。
2. Drive 18–24 dB，Character GABBER。
3. Punch 50–70%，Body 50%。
4. Ceiling -0.3 dB，Clip HARD。
5. 如果太糊，降低 Low Mix 或提高 Low Cut。

### Sub Keeper

1. 载入 **SUB KEEPER**。
2. Low Drive 0，Low Mix 10–25%。
3. Mid/High Drive 适度，Tone 稍微偏暗。
4. Mono ON，Low Cut 20–30 Hz。

\---

## 8\. 演示

`demo\\` 中有 6 个 48 kHz / 16-bit / 2.80 s WAV：

|文件|内容|
|-|-|
|`00\_clean\_reference.wav`|未处理参考 kick|
|`01\_hardstyle\_punch.wav`|HARDSTYLE PUNCH|
|`02\_rawstyle\_sermon.wav`|RAWSTYLE SERMON|
|`03\_frenchcore\_fold.wav`|FRENCHCORE FOLD|
|`04\_gabber\_hammer.wav`|GABBER HAMMER|
|`05\_total\_destruction.wav`|TOTAL DESTRUCTION|

!\[Demo waveforms](assets/demo\_waveforms.png)

\---

## 10\. 验证

当前构建通过：

* VST2 宿主验证：magic / version / 27 参数 / 10 预设 / chunk 148 字节 / 编辑器 1080×700 / open-idle-close。
* 10 预设 × 4 种过采样：输出 finite 且非静音。
* 9 组 scale / theme / style 组合 + 20 次 editor create/destroy，GDI 对象 delta = 2。
* DLL 卸载/重载：无编辑器、带编辑器、先销毁父窗口、正常 effEditClose/effClose 四种路径。
* 连续 20 次 unload/reload 循环无崩溃。

\---

## 11\. 稳定性修复（2.1.1）

FL 的事件日志曾出现：

```text
出错模块名称：KickForge.dll\_unloaded
异常代码：0xc000041d
错误偏移：0x16653
```

偏移 `0x16653` 落在编辑器窗口过程 `ed\_proc` 内（当前构建中 `ed\_proc` 的 RVA 为 `0x166fc`）。原因是宿主卸载 DLL 时，编辑器窗口/窗口类仍持有 DLL 内的窗口过程指针，之后任何窗口消息都会跳到已卸载的代码。

2.1.1 的修复：

* `Editor` 加入全局链表，记录所有活动编辑器。
* `DllMain(DLL\_PROCESS\_DETACH)` 调用 `kf\_editor\_detach\_all()`：

  * 停止每个编辑器的 timer；
  * 把 `GWLP\_WNDPROC` 替换为 `DefWindowProcA`；
  * 清空 `GWLP\_USERDATA`；
  * 同线程时销毁窗口；
  * 注销窗口类。
* 窗口类使用 DLL 自己的 `HINSTANCE`，并用唯一类名 + 失败重试，避免 DLL 重载后复用旧窗口过程。
* `kf\_editor\_destroy()` 在销毁窗口前先解除窗口过程/用户数据关联。
* `read\_chunk()` 不再直接跨线程重建 DIB，而是 `PostMessage(WM\_APP+7)` 到 UI 线程后应用缩放/配色。
* `effEditOpen` 检查父窗口有效性；`effSetChunk` 检查空指针/长度。
* 新增 `unload\_test.exe` 回归测试，构建时自动运行。

\---

## 12\. 故障排查

**FL 里找不到插件**

* 确认 `KickForge.dll` 在 `D:\\FL studio\\Plugins\\VST\\`。
* FL → Options → Manage plugins → 勾选 VST2 路径 → 重新扫描。
* 确认使用 64 位 FL。
* 有些 FL 版本需要重启后才刷新插件数据库。

**加载/卸载时闪退**

* 确认使用 2.1.2 的 `dist\\KickForge.dll`（121,344 字节）。
* 如果仍闪退，请把 Windows 事件查看器里的故障模块与偏移发来；不要混用旧版 DLL。
* 2.1.2 已覆盖编辑器窗口在 DLL 卸载后仍收到消息的崩溃路径。
* 2.1.2 新增全局主题记忆：若外观没有延续，检查 `%APPDATA%\\KickForge\\settings.ini` 或 DLL 同目录的 `KickForge.ini` 是否可写。

**加载后没有声音**

* 检查 Mix 是否被拉到 0。
* 检查 Bypass 是否开启。
* 检查输入通道是否有信号。
* 检查 Ceiling / Output 是否过低。

**CPU 占用高**

* 把 OS 从 4x/8x 降到 2x 或 1x。
* 关闭 Auto Gain。
* 这是三频段 + 过采样的非线性处理，8x 会明显更吃 CPU。

**切换预设/恢复工程时有短暂音量爬升**

* 2.1.1 在 preset load 和 chunk restore 后 prime DSP 平滑值；如果遇到，确认使用的是最新 DLL。

**UI 显示异常**

* 插件使用 GDI 绘制，远程桌面/极端 DPI 缩放下可能有细微差异。
* 在 **UI SETUP** 里切换 100/125/150%；125%/150% 会同时放大窗口和字体。
* Darkaero 界面是程序化绘制，不读取任何外部背景图。

\---

## 13\. 文件

```text
kickforge/
  src/             C 源码（VST2 ABI、DSP、参数、编辑器、测试）
  build.ps1        构建 + 验证脚本
  dist/            KickForge.dll
  demo/            6 个演示 WAV
  assets/          UI 预览、风格矩阵、设置页、波形图
  docs/            FL Studio 安装说明
  tools/tcc/       构建用 TinyCC
  README.md
```

\---

## 14\. 版本

* **2.1.2** — 全局 UI 记忆：比例、DARKAERO 外观和强调色在切换时写入 `%APPDATA%\\KickForge\\settings.ini`，新实例自动恢复；APPDATA 不可写时回退到 DLL 同目录 `KickForge.ini`；新增设置持久化测试与固定 `edit\_rect`，避免恢复 125%/150% 时宿主按旧尺寸开窗。
* **2.1.1** — 稳定性修复：编辑器窗口登记与 `DllMain(DLL\_PROCESS\_DETACH)` 清理；卸载时停止定时器、替换窗口过程、注销窗口类，修复 `KickForge.dll\_unloaded` / `0xc000041d` 崩溃；chunk 恢复的 UI 刷新改为 UI 线程消息；新增 unload/reload 生命周期测试。
* **2.1.0** — Darkaero 双外观：STYLE 01 冷铬玻璃 / STYLE 02 黑色分段铬甲；新增 ORIGINAL / MAGENTA / CRIMSON / INK BLUE 四色强调；UI SETUP 可同时切换外观、颜色与比例；chunk v3 保存外观/颜色；重新绘制分段铬甲、六角网格、旋钮齿纹与主题化电平表。
* **2.0.1** — Darkaero 视觉重构：冷蓝灰玻璃/镀铬单一样式，去除照片背景、旧四色主题和危险条纹。
* **2.0.0** — UI 2.0：100/125/150% 缩放、更大字体、四主题、金属背景开关、UI SETUP、chunk v2。
* **1.0.0** — 首个完整版本：三频段失真、6 曲线、过采样、10 预设、Metalheart/Y2K UI。

源码随附，可自行修改。没有使用第三方 DSP 库；TinyCC 仅用于构建。

