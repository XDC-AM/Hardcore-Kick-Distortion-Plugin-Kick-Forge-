# KickForge 2.1.2 在 FL Studio 25 中的安装

## 1. 复制 DLL

把：

```text
D:\鱼的工作区\kickforge\dist\KickForge.dll
```

复制到：

```text
D:\FL studio 25【完整至尊版】内含教程\Plugins\VST\KickForge.dll
```

只需要这一个文件；Darkaero 界面是程序化绘制，不读取背景图或主题文件。

## 2. 确认 FL 的 VST2 搜索路径

FL Studio 25 → **Options → Manage plugins**。

确认列表中有：

```text
D:\FL studio 25【完整至尊版】内含教程\Plugins\VST\
```

如果没有，点 **Add path** 添加，再点 **Find more plugins / Scan**。

> 必须使用 **FL64.exe**。KickForge 是 64 位 VST2，32 位 FL 无法加载。

## 3. 加载

1. 在浏览器里找到 **KickForge**。
2. 拖到 kick 通道，或右键通道 → **Replace**。
3. 首次加载后建议重启 FL，刷新插件数据库。

## 4. 快速开始

- 载入预设 **HARDSTYLE PUNCH** 先确认有声音。
- 如果输入 kick 已经很响，先把 **Input** 拉到 -6 dB。
- **Mono** 默认 ON，适合踢鼓。
- **Oversample** 默认 4x；CPU 紧张时改 2x。
- 用 **Output** 和 **Ceiling** 控制最终峰值。

## 5. UI SETUP

点击预设栏右侧 **UI SETUP**：

- **INTERFACE SCALE**：100% / 125% / 150%
- **DARKAERO FINISH**：
  - STYLE 01 — CHROME GLASS
  - STYLE 02 — BROOD CHROME
- **ACCENT COLOR**：
  - ORIGINAL 冰蓝
  - MAGENTA 品红
  - CRIMSON 深红
  - INK BLUE 墨蓝

设置写入 VST chunk，随工程保存；同时会立即写入用户级全局设置，新建工程或重新加载插件时恢复上次外观。

全局设置位置：

```text
%APPDATA%\KickForge\settings.ini
```

如果该目录不可写，会退回 DLL 同目录的 `KickForge.ini`。想恢复默认外观，关闭插件后删除该文件再打开。

切换比例会同时放大窗口和字体。

## 6. 卸载/重载闪退的修复

2.1.1 修复了 `KickForge.dll_unloaded` / `0xc000041d`，2.1.2 沿用并补充了设置记忆：

- 编辑器窗口登记到全局链表；
- DLL 卸载时停止 timer、替换窗口过程、清空 user data、注销窗口类；
- chunk 恢复改为 UI 线程消息，不再跨线程重建 DIB；
- 新增 `unload_test.exe`，覆盖“不关编辑器直接卸载 DLL”等路径。

如果仍遇到闪退，请记录 Windows 事件查看器中的：

- 故障模块名称
- 异常代码
- 错误偏移
- FL 版本

并确认使用的是 2.1.2 的 DLL（121,344 字节）。

## 7. 常见问题

**扫描不到**

- 确认路径存在，DLL 没有被杀毒软件隔离。
- 在 Manage plugins 里手动扫描该目录。
- 重启 FL。

**加载后没声音**

- 检查 Mix、Bypass、Output、Ceiling。
- 检查 kick 通道是否有输入。
- 先载入 INIT / CLEAN 排除预设问题。

**CPU 高**

- OS 改为 2x 或 1x。
- 关闭 Auto Gain。
- 减少不必要的过采样。

**界面模糊**

- 在 UI SETUP 切换到 125% 或 150%。
- 避免在远程桌面/非整数 DPI 缩放下观察。

**换了主题但下次没有记住**

- 确认没有混用旧版 DLL；2.1.2 才包含全局设置记忆。
- 检查 `%APPDATA%\KickForge\settings.ini` 是否存在。
- 如果 APPDATA 被安全软件拦截，设置会写到 DLL 同目录的 `KickForge.ini`。
- 删除上述文件可恢复默认外观。
